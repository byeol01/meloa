var mainvideo = document.getElementById("mvideo");
if(mainvideo.requestFullscreen) {
  mainvideo.requestFullscreen();
} else if (mainvideo.mozRequestFullScreen) {
  mainvideo.mozRequestFullScreen();
} else if (mainvideo.webkitRequestFullScreen) {
  mainvideo.webkitRequestFullScreen();
} 